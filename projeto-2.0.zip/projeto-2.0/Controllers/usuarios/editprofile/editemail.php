<?php
if(!hasUser()){
    header('Location: /');
}
?>